# RK3588_AIBOX_PLUS

### sdk 编译须知

具体看wiki介绍，链接：https://gitee.com/owlvisiontech/rk3588_linux_sdk_patch/wikis/Home
### 电源控制

|      名称       | 主控引脚 | 引脚标识 | 有效电平 |                             备注                             |
| :-------------: | :------: | :------: | :------: | :----------------------------------------------------------: |
|  USB外设总电源  |   D29    | GPIO1_C6 |    H     | 所有USB接口的总电源，使用到任意一个USB口的话，都需要开启此路电源 |
| USB2.0 HOST电源 |   AK26   | GPIO4_B0 |    H     |       两个USB2.0公口的Vbus电源，电压为5V，与USB3.0共用       |
| USB3.0 HOST电源 |   AK26   | GPIO4_B0 |    H     |         两个USB3.0公口中下方公口的Vbus电源，电压为5V         |
|  Typec接口电源  |   AD2    | GPIO4_D0 |    H     | 两个USB3.0公口中下方公口的Vbus电源，电压为5V，与Typec口共用  |
|  SATA接口电源   |   AB28   | GPIO3_D5 |    H     |                       硬盘12V供电开关                        |

### 外设描述

| 外设类型 | 芯片型号  | 接口分配 | 引脚分配                                                     | 控制逻辑 | 说明                                                         |
| :------- | :-------- | :------- | :----------------------------------------------------------- | :------- | :----------------------------------------------------------- |
| RTC      | HYM8563   | I2C2     | SCL ：T28  GPIO0_B7_d<br />SDA ： T31  GPIO0_C0_d<br />RTC_INT：  V29  GPIO0_D4_d | /        | IIC 400KHz <br />INT低有效复位                               |
| WIFI6    | AP6275PR3 | PCIE20   | Reset：AK27-GPIO4_A5_d<br />HOST_WAKE_WIFI：AH29  GPIO3_B1_d<br />WIFI_WAKE_HOST：AG29  GPIO3_A7_u |          | HOST_WAKE_WIFI：CPU使能WIFI，高有效<br />WIFI_WAKE_HOST：WIFI唤醒主控，低电平有效 |
| DSI0     |           |          |                                                              |          |                                                              |
| MIPIRX0  |           |          |                                                              |          |                                                              |
| MIPIRX1  |           |          |                                                              |          |                                                              |
| MIPIRX2  |           |          |                                                              |          |                                                              |
| MIPIRX3  |           |          |                                                              |          |                                                              |
|          |           |          |                                                              |          |                                                              |
|          |           |          |                                                              |          |                                                              |
